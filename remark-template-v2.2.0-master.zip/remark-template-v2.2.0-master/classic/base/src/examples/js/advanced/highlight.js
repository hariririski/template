(function(document, window, $) {
  'use strict';

  var Site = window.Site;

  $(document).ready(function($) {
    Site.run();
  });

  hljs.initHighlightingOnLoad();


})(document, window, jQuery);
